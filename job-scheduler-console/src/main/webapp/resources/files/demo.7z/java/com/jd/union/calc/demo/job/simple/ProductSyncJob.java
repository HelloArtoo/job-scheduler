package com.jd.union.calc.demo.job.simple;

import java.util.Date;
import java.util.List;

import com.jd.framework.job.api.SegmentContext;
import com.jd.framework.job.api.simple.SimpleJob;
import com.jd.union.calc.demo.domain.TestProduct;
import com.jd.union.calc.demo.service.ProductService;
import com.jd.union.calc.demo.service.ProductServiceFactory;

/**
 * @author hurong
 *
 * @description: 商品同步至数据源
 */
public class ProductSyncJob implements SimpleJob {

    private ProductService productSerice = ProductServiceFactory.getSerivce();
    // 一帧50个SKU
    private final int FRAME_COUNT = 50;

    @Override
    public void execute(SegmentContext segmentContext) {

        System.out.println(String.format("@@Job-Scheduller@@: Thread ID: %s, Date: %s, Segment Context: %s, Action: %s",
            Thread.currentThread().getId(), new Date(), segmentContext, " simple job executing."));

        //@Job-Scheduller@@: Thread ID: 23, Date: Sat Jul 15 14:58:40 CST 2017, Segment Context: SegmentContext(segmentItem=0, segmentsSum=3, jobName=daily_buying_plan_test, taskId=daily_buying_plan_test@-@0,1,2@-@READY@-@10.0.4.151@-@1e825264-b8b8-4f66-8479-01810853527d, jobParameter=, segmentParameter=6), Action:  simple job executing.
        //@@Job-Scheduller@@: Thread ID: 24, Date: Sat Jul 15 14:58:40 CST 2017, Segment Context: SegmentContext(segmentItem=1, segmentsSum=3, jobName=daily_buying_plan_test, taskId=daily_buying_plan_test@-@0,1,2@-@READY@-@10.0.4.151@-@1e825264-b8b8-4f66-8479-01810853527d, jobParameter=, segmentParameter=3), Action:  simple job executing.
        //@@Job-Scheduller@@: Thread ID: 25, Date: Sat Jul 15 14:58:40 CST 2017, Segment Context: SegmentContext(segmentItem=2, segmentsSum=3, jobName=daily_buying_plan_test, taskId=daily_buying_plan_test@-@0,1,2@-@READY@-@10.0.4.151@-@1e825264-b8b8-4f66-8479-01810853527d, jobParameter=, segmentParameter=10), Action:  simple job executing.
        
        
        
        List<TestProduct> data = productSerice.fetchProducts(segmentContext.getSegmentParameter(), FRAME_COUNT);
        for (TestProduct each : data) {
            each.setDone(true);
            System.out.println(
                String.format("Product {sku: [%s],productName:[%s]} is done. ", each.getSku(), each.getProductName()));
        }
    }

}
