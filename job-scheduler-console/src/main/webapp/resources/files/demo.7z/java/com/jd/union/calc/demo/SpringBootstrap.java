package com.jd.union.calc.demo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * @author hurong
 *
 * @description: Spring 方式配置项目
 */
public class SpringBootstrap {

    @SuppressWarnings({ "unused", "resource" })
	public static void main(String[] args) {

		ApplicationContext ctx = new ClassPathXmlApplicationContext("classpath:spring-jobs-simple-test.xml");
        
    }

}
