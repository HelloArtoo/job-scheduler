package com.jd.union.calc;

import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * @author gengzhenhua
 *
 * @description: 测试父类
 */
@RunWith(value=SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"/spring/test-calc-application-context.xml"})
public class BaseJunitTest {
    
}
